Exercise 1:

SELECT *
FROM KpiPaa
WHERE Identificador LIKE 'IPC%';
